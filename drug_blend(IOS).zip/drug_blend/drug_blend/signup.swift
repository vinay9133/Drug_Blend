//
//  signup.swift
//  drug_blend
//
//  Created by Nithin on 7/11/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit

class signup: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    var userrdetails = ["vinay":"9133"]
    
    
    @IBOutlet weak var phonenumber: UITextField!
    
    @IBOutlet weak var uname: UITextField!
    
    @IBOutlet weak var pass: UITextField!
    
    @IBOutlet weak var Address: UITextField!
    
    @IBAction func signupfunc(_ sender: Any) {
        if let username = uname.text, !username.isEmpty,
           let password = pass.text, !password.isEmpty,
           let phoneNumber = phonenumber.text, !phoneNumber.isEmpty,
           let address = Address.text, !address.isEmpty {
            userrdetails[username] = password
            udata = userrdetails
            performSegue(withIdentifier: "sign", sender: nil)
        } else {
            let alert = UIAlertController(title: "Incomplete Information", message: "Please fill in all fields correctly.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
}
