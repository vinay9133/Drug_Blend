//
//  finalpayment.swift
//  drug_blend
//
//  Created by Nithin on 2/11/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit

class finalpayment: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var total: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var total1 = 0.0
        for cart in cartmanager.shared.carts{
            total1 = total1 + cart.cost
        }
        total.text = "\(total1)"
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cartmanager.shared.carts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var obj = tableView.dequeueReusableCell(withIdentifier: "c1", for: indexPath)
        obj.textLabel?.text = "\(cartmanager.shared.carts[indexPath.row].name),  \(cartmanager.shared.carts[indexPath.row].cost)"
        return obj
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var name = total.text!
        if segue.identifier == "done"{
            var dest  = segue.destination as! Done
            dest.name = name
        }
        
        
        
    }
    
}
