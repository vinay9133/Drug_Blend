//
//  myCollectionview.swift
//  drug_blend
//
//  Created by Nithin on 27/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit

class myCollectionview: UICollectionViewCell {
    
    @IBOutlet weak var myimage: UIImageView!
    
}
