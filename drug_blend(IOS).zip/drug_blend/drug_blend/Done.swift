//
//  Done.swift
//  drug_blend
//
//  Created by Nithin on 2/11/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit
import AVFoundation
class Done: UIViewController {
    var name: String = ""
    var vlc:AVAudioPlayer!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    
    @IBAction func done(_ sender: Any) {
        var alt2 = UIAlertController(title: "Successful", message: "We Recieved your payment of \(name). Your Medicines will reach you in 2 days to your address.. Thank You!! Please Visit Again", preferredStyle: UIAlertController.Style.alert)
        
        

        alt2.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.destructive, handler: nil))
        present(alt2,animated: true)    }
    
}
