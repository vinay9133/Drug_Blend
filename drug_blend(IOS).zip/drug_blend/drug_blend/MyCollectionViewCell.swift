//
//  MyCollectionViewCell.swift
//  drug_blend
//
//  Created by Nithin on 29/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myImageView: UIImageView!
}
