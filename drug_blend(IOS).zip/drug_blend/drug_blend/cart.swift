//
//  cart.swift
//  drug_blend
//
//  Created by Nithin on 2/11/23.
//  Copyright © 2023 Student. All rights reserved.
//

import Foundation
struct cart{
    var name:String
    var cost:Double
    
}
class cartmanager{
    
    static let shared = cartmanager()
    var carts:[cart]=[]
    
    func addcart(_ Cart:cart){
        carts.append(Cart)
    }
    
    
}
